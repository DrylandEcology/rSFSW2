Rsoilwat_v27

This is a great tool for easy use of soilwat from within R.


Compile (linux or osx)
To compile from command line.
tar czf Rsoilwat_v27.tar.gz Rsoilwat
R CMD INSTALL Rsoilwat_v27.tar.gz

for windows download the R build tools

Use
This section needs to be written
